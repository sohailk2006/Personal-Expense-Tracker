"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { TrendingDown, TrendingUp, Wallet, Target } from "lucide-react"
import type { Expense, Budget } from "../types/expense"
import {
  calculateCategoryTotals,
  calculateBudgetStatus,
  formatCurrency,
  getBudgetAlertLevel,
  getBudgetAlertMessage,
} from "../utils/expense-utils"

interface DashboardOverviewProps {
  expenses: Expense[]
  budgets: Budget[]
}

export function DashboardOverview({ expenses, budgets }: DashboardOverviewProps) {
  const currentMonth = new Date().getMonth()
  const currentYear = new Date().getFullYear()

  const monthlyExpenses = expenses.filter((expense) => {
    const expenseDate = new Date(expense.date)
    return expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear
  })

  const totalIncome = monthlyExpenses
    .filter((expense) => expense.type === "income")
    .reduce((sum, expense) => sum + expense.amount, 0)

  const totalExpenses = monthlyExpenses
    .filter((expense) => expense.type === "expense")
    .reduce((sum, expense) => sum + expense.amount, 0)

  const balance = totalIncome - totalExpenses
  const categoryTotals = calculateCategoryTotals(monthlyExpenses)
  const budgetStatus = calculateBudgetStatus(monthlyExpenses, budgets)

  const totalBudget = budgets.reduce((sum, budget) => sum + budget.limit, 0)

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Income</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatCurrency(totalIncome)}</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{formatCurrency(totalExpenses)}</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Balance</CardTitle>
            <Wallet className={`h-4 w-4 ${balance >= 0 ? "text-green-600" : "text-red-600"}`} />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${balance >= 0 ? "text-green-600" : "text-red-600"}`}>
              {formatCurrency(balance)}
            </div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Budget Used</CardTitle>
            <Target className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {totalBudget > 0 ? `${Math.round((totalExpenses / totalBudget) * 100)}%` : "0%"}
            </div>
            <p className="text-xs text-muted-foreground">Of total budget</p>
          </CardContent>
        </Card>
      </div>

      {/* Budget Alerts */}
      {budgets.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Budget Alerts</CardTitle>
            <CardDescription>Monitor your spending limits</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {budgetStatus.map((budget) => {
                const alertLevel = getBudgetAlertLevel(budget.spent, budget.limit)
                const alertMessage = getBudgetAlertMessage(budget.spent, budget.limit)

                if (alertLevel === "safe") return null

                const getAlertIcon = (level: string) => {
                  switch (level) {
                    case "over":
                      return "🚨"
                    case "danger":
                      return "⚠️"
                    case "warning":
                      return "⚡"
                    default:
                      return "✅"
                  }
                }

                const getAlertColor = (level: string) => {
                  switch (level) {
                    case "over":
                      return "border-red-200 bg-red-50"
                    case "danger":
                      return "border-red-200 bg-red-50"
                    case "warning":
                      return "border-orange-200 bg-orange-50"
                    default:
                      return "border-green-200 bg-green-50"
                  }
                }

                return (
                  <div key={budget.category} className={`p-3 rounded-lg border ${getAlertColor(alertLevel)}`}>
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{getAlertIcon(alertLevel)}</span>
                      <div>
                        <p className="font-medium">{budget.category}</p>
                        <p className="text-sm text-muted-foreground">{alertMessage}</p>
                      </div>
                    </div>
                  </div>
                )
              })}
              {budgetStatus.every((budget) => getBudgetAlertLevel(budget.spent, budget.limit) === "safe") && (
                <div className="text-center py-4 text-green-600">
                  <span className="text-2xl">✅</span>
                  <p className="mt-2">All budgets are on track!</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Spending Insights */}
      <Card>
        <CardHeader>
          <CardTitle>Spending Insights</CardTitle>
          <CardDescription>Detailed analysis of your expenses</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {categoryTotals.length > 0 ? (
              categoryTotals
                .sort((a, b) => b.total - a.total)
                .slice(0, 6)
                .map((category, index) => {
                  const percentage = totalExpenses > 0 ? (category.total / totalExpenses) * 100 : 0
                  const isTopSpender = index === 0

                  return (
                    <div
                      key={category.category}
                      className={`p-4 rounded-lg border ${isTopSpender ? "border-orange-200 bg-orange-50" : "border-gray-200"}`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-sm">{category.category}</h4>
                        {isTopSpender && (
                          <span className="text-xs bg-orange-200 text-orange-800 px-2 py-1 rounded">Top Spend</span>
                        )}
                      </div>
                      <p className="text-2xl font-bold">{formatCurrency(category.total)}</p>
                      <p className="text-sm text-muted-foreground">{percentage.toFixed(1)}% of total spending</p>
                      <div className="mt-2 bg-gray-200 rounded-full h-2">
                        <div className="bg-blue-500 h-2 rounded-full" style={{ width: `${percentage}%` }}></div>
                      </div>
                    </div>
                  )
                })
            ) : (
              <div className="col-span-full text-center py-8 text-muted-foreground">
                No spending data available for insights
              </div>
            )}
          </div>

          {/* Daily Average */}
          {totalExpenses > 0 && (
            <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <h4 className="font-medium text-blue-900 mb-2">Daily Spending Average</h4>
              <p className="text-2xl font-bold text-blue-900">{formatCurrency(totalExpenses / new Date().getDate())}</p>
              <p className="text-sm text-blue-700">Based on {new Date().getDate()} days this month</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Spending by Category Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Spending by Category</CardTitle>
            <CardDescription>This month's expense breakdown</CardDescription>
          </CardHeader>
          <CardContent>
            {categoryTotals.length > 0 ? (
              <ChartContainer
                config={categoryTotals.reduce(
                  (acc, item) => ({
                    ...acc,
                    [item.category]: {
                      label: item.category,
                      color: item.color,
                    },
                  }),
                  {},
                )}
                className="h-[300px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryTotals}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="total"
                      label={({ category, total }) => `${category}: ${formatCurrency(total)}`}
                    >
                      {categoryTotals.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <ChartTooltip content={<ChartTooltipContent />} />
                  </PieChart>
                </ResponsiveContainer>
              </ChartContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                No expense data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Budget vs Actual Bar Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Budget vs Actual</CardTitle>
            <CardDescription>Compare your spending to budgets</CardDescription>
          </CardHeader>
          <CardContent>
            {budgetStatus.length > 0 ? (
              <ChartContainer
                config={{
                  budget: {
                    label: "Budget",
                    color: "hsl(var(--chart-1))",
                  },
                  spent: {
                    label: "Spent",
                    color: "hsl(var(--chart-2))",
                  },
                }}
                className="h-[300px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={budgetStatus}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="category" tick={{ fontSize: 12 }} angle={-45} textAnchor="end" height={80} />
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="limit" fill="var(--color-budget)" name="Budget" />
                    <Bar dataKey="spent" fill="var(--color-spent)" name="Spent" />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                No budget data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
