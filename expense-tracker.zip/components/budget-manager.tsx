"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import type { Budget } from "../types/expense"
import { categories, formatCurrency, getBudgetAlertLevel, getBudgetAlertMessage } from "../utils/expense-utils"

interface BudgetManagerProps {
  budgets: Budget[]
  onUpdateBudget: (category: string, limit: number) => void
}

export function BudgetManager({ budgets, onUpdateBudget }: BudgetManagerProps) {
  const [selectedCategory, setSelectedCategory] = useState("")
  const [budgetAmount, setBudgetAmount] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!selectedCategory || !budgetAmount) {
      return
    }

    onUpdateBudget(selectedCategory, Number.parseFloat(budgetAmount))
    setSelectedCategory("")
    setBudgetAmount("")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Budget Management</CardTitle>
        <CardDescription>Set and track your spending limits</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="budget-category">Category</Label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="budget-amount">Budget Limit</Label>
                <Input
                  id="budget-amount"
                  type="number"
                  step="0.01"
                  placeholder="₹0.00"
                  value={budgetAmount}
                  onChange={(e) => setBudgetAmount(e.target.value)}
                  required
                />
              </div>
            </div>
            <Button type="submit" className="w-full">
              Set Budget
            </Button>
          </form>

          <div className="space-y-4">
            <h3 className="font-semibold">Current Budgets</h3>
            {budgets.length === 0 ? (
              <p className="text-center text-muted-foreground py-4">No budgets set yet</p>
            ) : (
              budgets.map((budget) => {
                const percentage = (budget.spent / budget.limit) * 100
                const alertLevel = getBudgetAlertLevel(budget.spent, budget.limit)
                const alertMessage = getBudgetAlertMessage(budget.spent, budget.limit)

                const getAlertColor = (level: string) => {
                  switch (level) {
                    case "over":
                      return "text-red-600 bg-red-50 border-red-200"
                    case "danger":
                      return "text-red-600 bg-red-50 border-red-200"
                    case "warning":
                      return "text-orange-600 bg-orange-50 border-orange-200"
                    default:
                      return "text-green-600 bg-green-50 border-green-200"
                  }
                }

                const getProgressColor = (level: string) => {
                  switch (level) {
                    case "over":
                      return "bg-red-500"
                    case "danger":
                      return "bg-red-500"
                    case "warning":
                      return "bg-orange-500"
                    default:
                      return "bg-green-500"
                  }
                }

                return (
                  <div key={budget.category} className="space-y-3 p-4 border rounded-lg">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">{budget.category}</span>
                      <span className="text-sm text-muted-foreground">
                        {formatCurrency(budget.spent)} / {formatCurrency(budget.limit)}
                      </span>
                    </div>
                    <div className="space-y-2">
                      <Progress value={Math.min(percentage, 100)} className="h-3" />
                      <div className={`text-sm p-2 rounded border ${getAlertColor(alertLevel)}`}>{alertMessage}</div>
                    </div>
                  </div>
                )
              })
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
