export interface Expense {
  id: string
  amount: number
  description: string
  category: string
  date: string
  type: "expense" | "income"
}

export interface Budget {
  category: string
  limit: number
  spent: number
}

export interface CategoryTotal {
  category: string
  total: number
  color: string
}
