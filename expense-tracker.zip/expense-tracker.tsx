"use client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DashboardOverview } from "./components/dashboard-overview"
import { ExpenseForm } from "./components/expense-form"
import { ExpenseList } from "./components/expense-list"
import { BudgetManager } from "./components/budget-manager"
import { useExpenses } from "./hooks/use-expenses"
import { BarChart3, Plus, List, Target } from "lucide-react"

export default function ExpenseTracker() {
  const { expenses, budgets, addExpense, deleteExpense, updateBudget } = useExpenses()

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Personal Expense Tracker</h1>
          <p className="text-gray-600 mt-2">Manage your budget and track your spending</p>
        </div>

        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="add" className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Transaction
            </TabsTrigger>
            <TabsTrigger value="transactions" className="flex items-center gap-2">
              <List className="h-4 w-4" />
              Transactions
            </TabsTrigger>
            <TabsTrigger value="budget" className="flex items-center gap-2">
              <Target className="h-4 w-4" />
              Budget
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <DashboardOverview expenses={expenses} budgets={budgets} />
          </TabsContent>

          <TabsContent value="add">
            <div className="max-w-2xl mx-auto">
              <ExpenseForm onAddExpense={addExpense} />
            </div>
          </TabsContent>

          <TabsContent value="transactions">
            <ExpenseList expenses={expenses} onDeleteExpense={deleteExpense} />
          </TabsContent>

          <TabsContent value="budget">
            <div className="max-w-2xl mx-auto">
              <BudgetManager budgets={budgets} onUpdateBudget={updateBudget} />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
