import ExpenseTracker from "../expense-tracker"

export default function Page() {
  return <ExpenseTracker />
}
