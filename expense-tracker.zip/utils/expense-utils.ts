import type { Expense, Budget, CategoryTotal } from "../types/expense"

export const categories = [
  "Food & Dining",
  "Transportation",
  "Shopping",
  "Entertainment",
  "Bills & Utilities",
  "Healthcare",
  "Travel",
  "Education",
  "Other",
]

export const categoryColors = {
  "Food & Dining": "hsl(var(--chart-1))",
  Transportation: "hsl(var(--chart-2))",
  Shopping: "hsl(var(--chart-3))",
  Entertainment: "hsl(var(--chart-4))",
  "Bills & Utilities": "hsl(var(--chart-5))",
  Healthcare: "hsl(220, 70%, 50%)",
  Travel: "hsl(280, 70%, 50%)",
  Education: "hsl(340, 70%, 50%)",
  Other: "hsl(200, 70%, 50%)",
}

export function calculateCategoryTotals(expenses: Expense[]): CategoryTotal[] {
  const totals = expenses
    .filter((expense) => expense.type === "expense")
    .reduce(
      (acc, expense) => {
        acc[expense.category] = (acc[expense.category] || 0) + expense.amount
        return acc
      },
      {} as Record<string, number>,
    )

  return Object.entries(totals).map(([category, total]) => ({
    category,
    total,
    color: categoryColors[category as keyof typeof categoryColors] || categoryColors.Other,
  }))
}

export function calculateBudgetStatus(expenses: Expense[], budgets: Budget[]): Budget[] {
  const categorySpending = expenses
    .filter((expense) => expense.type === "expense")
    .reduce(
      (acc, expense) => {
        acc[expense.category] = (acc[expense.category] || 0) + expense.amount
        return acc
      },
      {} as Record<string, number>,
    )

  return budgets.map((budget) => ({
    ...budget,
    spent: categorySpending[budget.category] || 0,
  }))
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
  }).format(amount)
}

export function getBudgetAlertLevel(spent: number, limit: number): "safe" | "warning" | "danger" | "over" {
  const percentage = (spent / limit) * 100
  if (percentage >= 100) return "over"
  if (percentage >= 90) return "danger"
  if (percentage >= 75) return "warning"
  return "safe"
}

export function getBudgetAlertMessage(spent: number, limit: number): string {
  const percentage = (spent / limit) * 100
  const remaining = limit - spent

  if (percentage >= 100) {
    return `Over budget by ${formatCurrency(spent - limit)}`
  }
  if (percentage >= 90) {
    return `Only ${formatCurrency(remaining)} left! (${Math.round(100 - percentage)}% remaining)`
  }
  if (percentage >= 75) {
    return `Approaching limit - ${formatCurrency(remaining)} remaining`
  }
  return `${formatCurrency(remaining)} remaining`
}
