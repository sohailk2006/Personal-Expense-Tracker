"use client"

import { useState, useEffect } from "react"
import type { Expense, Budget } from "../types/expense"

export function useExpenses() {
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [budgets, setBudgets] = useState<Budget[]>([])

  // Load data from localStorage on mount
  useEffect(() => {
    const savedExpenses = localStorage.getItem("expenses")
    const savedBudgets = localStorage.getItem("budgets")

    if (savedExpenses) {
      setExpenses(JSON.parse(savedExpenses))
    }

    if (savedBudgets) {
      setBudgets(JSON.parse(savedBudgets))
    }
  }, [])

  // Save to localStorage whenever data changes
  useEffect(() => {
    localStorage.setItem("expenses", JSON.stringify(expenses))
  }, [expenses])

  useEffect(() => {
    localStorage.setItem("budgets", JSON.stringify(budgets))
  }, [budgets])

  const addExpense = (expense: Omit<Expense, "id">) => {
    const newExpense = {
      ...expense,
      id: Date.now().toString(),
    }
    setExpenses((prev) => [newExpense, ...prev])
  }

  const deleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((expense) => expense.id !== id))
  }

  const updateBudget = (category: string, limit: number) => {
    setBudgets((prev) => {
      const existing = prev.find((b) => b.category === category)
      if (existing) {
        return prev.map((b) => (b.category === category ? { ...b, limit } : b))
      } else {
        return [...prev, { category, limit, spent: 0 }]
      }
    })
  }

  return {
    expenses,
    budgets,
    addExpense,
    deleteExpense,
    updateBudget,
  }
}
